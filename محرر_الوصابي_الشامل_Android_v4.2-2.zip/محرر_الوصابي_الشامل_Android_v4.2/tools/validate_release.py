from pathlib import Path
import re, sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
checks=[]
app=(root/"app/build.gradle").read_text(encoding="utf-8")
checks.append(("versionName 4.2", "versionName '4.2'" in app))
checks.append(("versionCode 22", "versionCode 22" in app))
checks.append(("applicationId", "applicationId 'com.wesabi.exameditor'" in app))
checks.append(("MainActivity", (root/"app/src/main/java/com/wesabi/exameditor/MainActivity.kt").exists()))
checks.append(("README", (root/"README.md").exists()))
checks.append(("validator", (root/"tools/validate_project.py").exists()))
for n,ok in checks: print(("PASS" if ok else "FAIL")+": "+n)
print("RELEASE VALIDATION:", "PASS" if all(x[1] for x in checks) else "FAIL")
sys.exit(0 if all(x[1] for x in checks) else 1)
