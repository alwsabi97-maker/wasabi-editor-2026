from pathlib import Path
import re, sys, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
required=[root/'settings.gradle',root/'build.gradle',root/'app/build.gradle',root/'app/src/main/AndroidManifest.xml',root/'app/src/main/java/com/wesabi/exameditor/MainActivity.kt',root/'app/src/main/res/values/styles.xml']
errors=[]
for f in required:
    if not f.exists() or f.stat().st_size==0: errors.append(f"Missing/empty: {f.relative_to(root)}")
g=(root/'app/build.gradle').read_text(encoding='utf-8')
m=re.search(r"versionName ['\"]([^'\"]+)",g)
if not m or m.group(1)!='4.0': errors.append('versionName is not 4.0')
manifest=root/'app/src/main/AndroidManifest.xml'
try: ET.parse(manifest)
except Exception as e: errors.append(f'Manifest XML error: {e}')
k=(root/'app/src/main/java/com/wesabi/exameditor/MainActivity.kt').read_text(encoding='utf-8')
for token in ['class MainActivity','renderPdf()','saveMeta()','loadExam()','version","4.0']:
    if token not in k: errors.append(f'Missing expected token: {token}')
print('VALIDATION: PASS' if not errors else 'VALIDATION: FAIL')
for e in errors: print('-',e)
sys.exit(1 if errors else 0)
