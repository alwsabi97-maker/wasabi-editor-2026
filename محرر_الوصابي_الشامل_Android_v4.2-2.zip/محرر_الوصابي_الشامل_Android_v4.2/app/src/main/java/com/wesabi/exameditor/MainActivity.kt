package com.wesabi.exameditor

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.content.*
import android.net.Uri
import android.print.*
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.view.*
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextDirectionHeuristics
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import org.json.JSONArray
import org.json.JSONObject

private data class Q(var type:String, var text:String="", var options:MutableList<String> = mutableListOf(), var marks:String="1", var answer:String="", var unit:String="", var imageUri:String="")

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val qs = mutableListOf<Q>()
    private val bank = mutableListOf<Q>()
    private val pref by lazy { getSharedPreferences("wesabi", MODE_PRIVATE) }
    private var school="مدرسة النور بالروحاء"; private var teacher="الأستاذ محمد سليمان الوصابي"
    private var subject=""; private var grade=""; private var title="اختبار"; private var term=""; private var academicYear=""
    private var watermark="إعداد الأستاذ / محمد سليمان الوصابي"; private var showBoxes=true; private var showPageNumbers=true; private var pageOrientation="عمودي"
    private var pending=ByteArray(0); private var pendingMime=""; private var pendingName=""
    private var sectionTitle=""
    private var instructions=""
    private var examDuration=""
    private var logoUri=""
    private var renderFontSize=14f
    private var pageMargin=38f
    private var lineSpacing=2f
    private var showPageBorder=false
    private var footerText=""
    private var pendingQuestionIndex=-1

    override fun onCreate(b: Bundle?) { super.onCreate(b); load(); loadBank(); loadExam(); home() }
    override fun onPause(){ super.onPause(); saveMeta(); saveBank() }

    private fun qToJson(q:Q)=JSONObject().apply { put("type",q.type);put("text",q.text);put("marks",q.marks);put("answer",q.answer);put("options",JSONArray(q.options)); put("unit",q.unit); put("imageUri",q.imageUri) }
    private fun qFromJson(o:JSONObject)=Q(o.optString("type"),o.optString("text"),mutableListOf<String>().apply { o.optJSONArray("options")?.let { a -> for(i in 0 until a.length()) add(a.optString(i)) } },o.optString("marks","1"),o.optString("answer"),o.optString("unit",""),o.optString("imageUri",""))
    private fun cloneQ(q:Q)=Q(q.type,q.text,q.options.toMutableList(),q.marks,q.answer,q.unit,q.imageUri)
    private fun saveList(key:String,list:List<Q>){ val a=JSONArray();list.forEach{a.put(qToJson(it))};pref.edit().putString(key,a.toString()).apply() }
    private fun loadList(key:String,target:MutableList<Q>){target.clear();val a=JSONArray(pref.getString(key,"[]"));for(i in 0 until a.length())target.add(qFromJson(a.getJSONObject(i)))}
    private fun saveExam(){saveList("exam",qs)}
    private fun loadExam(){loadList("exam",qs)}
    private fun saveBank(){saveList("bank",bank)}
    private fun addToBankUnique(items:List<Q>):Int{var added=0;items.forEach{q->if(bank.none{it.type==q.type && it.text.trim()==q.text.trim()}){bank.add(cloneQ(q));added++}};saveBank();return added}
    private fun loadBank(){loadList("bank",bank)}
    private fun saveMeta(){pref.edit().putString("school",school).putString("teacher",teacher).putString("subject",subject).putString("grade",grade).putString("title",title).putString("sectionTitle",sectionTitle).putString("instructions",instructions).putString("examDuration",examDuration).putString("logoUri",logoUri).putString("watermark",watermark).putString("term",term).putString("academicYear",academicYear).putBoolean("showBoxes",showBoxes).putBoolean("showPageNumbers",showPageNumbers).putString("pageOrientation",pageOrientation).putFloat("renderFontSize",renderFontSize).putFloat("pageMargin",pageMargin).putFloat("lineSpacing",lineSpacing).putBoolean("showPageBorder",showPageBorder).putString("footerText",footerText).apply();saveExam()}
    private fun load(){renderFontSize=pref.getFloat("renderFontSize",14f);pageMargin=pref.getFloat("pageMargin",38f);lineSpacing=pref.getFloat("lineSpacing",2f);showPageBorder=pref.getBoolean("showPageBorder",false);footerText=pref.getString("footerText","")!!;showBoxes=pref.getBoolean("showBoxes",true);showPageNumbers=pref.getBoolean("showPageNumbers",true);pageOrientation=pref.getString("pageOrientation","عمودي")!!;school=pref.getString("school",school)!!;teacher=pref.getString("teacher",teacher)!!;subject=pref.getString("subject","")!!;grade=pref.getString("grade","")!!;title=pref.getString("title",title)!!;watermark=pref.getString("watermark",watermark)!!;term=pref.getString("term","")!!;academicYear=pref.getString("academicYear","")!!;sectionTitle=pref.getString("sectionTitle","")!!;instructions=pref.getString("instructions","")!!;examDuration=pref.getString("examDuration","")!!;logoUri=pref.getString("logoUri","")!!}

    private fun shell(t:String){
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(16,10,16,16);setBackgroundColor(Color.rgb(247,249,252))}
        root.addView(TextView(this).apply{text=t;textSize=21f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setTypeface(Typeface.DEFAULT,Typeface.BOLD);setBackgroundColor(Color.rgb(23,105,170));setPadding(8,18,8,18)},LinearLayout.LayoutParams(-1,-2))
        val sv=ScrollView(this); val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}; root.addView(sv,LinearLayout.LayoutParams(-1,0,1f));sv.addView(content)
        val old=root; root=content; setContentView(old)
    }
    private fun btn(t:String,a:()->Unit)=Button(this).apply{text=t;textSize=16f;isAllCaps=false;setOnClickListener{a()}}
    private fun addBtn(t:String,a:()->Unit){root.addView(btn(t,a),LinearLayout.LayoutParams(-1,58).apply{setMargins(0,4,0,4)})}
    private fun input(h:String,v:String,change:(String)->Unit)=EditText(this).apply{
        hint=h;setText(v);textSize=16f;gravity=Gravity.RIGHT;layoutDirection=View.LAYOUT_DIRECTION_RTL
        addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){change(s?.toString()?: "")};override fun afterTextChanged(e:Editable?){}})
    }
    private fun info(t:String){root.addView(TextView(this).apply{text=t;textSize=16f;gravity=Gravity.RIGHT;setPadding(8,14,8,14)})}

    private fun examCompletenessSummary():String{
        val empty=qs.count{it.text.trim().isBlank()}
        val badMarks=qs.count{it.marks.toFloatOrNull()?.let{m->m<=0}?:true}
        val badMc=qs.count{it.type=="اختيار من متعدد" && (it.options.size<4 || it.options.any{op->op.trim().isBlank()} || it.answer !in listOf("أ","ب","ج","د"))}
        val badTf=qs.count{it.type=="صح / خطأ" && it.answer !in listOf("ص","خ")}
        return "أسئلة: ${qs.size} | فارغة: $empty | درجات غير صحيحة: $badMarks | اختيار من متعدد يحتاج مراجعة: $badMc | صح/خطأ يحتاج مراجعة: $badTf"
    }

    private fun home(){shell("محرر الوصابي الشامل");info("منصة إعداد الاختبارات المدرسية\n$school\n\nعدد أسئلة الاختبار: ${qs.size} — بنك الأسئلة: ${bank.size}
إجمالي الدرجات: ${totalMarks()}\n\nحالة الاختبار: ${examCompletenessSummary()}");addBtn("➕ إنشاء / تعديل اختبار"){editor()};addBtn("🗃 الاختبارات المحفوظة"){libraryScreen()};addBtn("📑 قوالب الاختبارات"){templatesScreen()};addBtn("⚡ توليد اختبار تلقائي"){autoGenerate()};addBtn("🧠 مخطط الاختبار الذكي"){examBlueprint()};addBtn("📚 بنك الأسئلة"){bankScreen()};addBtn("👁 معاينة الورقة"){preview()};addBtn("📊 إحصاءات الاختبار"){statistics()};addBtn("🧮 توزيع الدرجات حسب النوع"){markStatistics()};addBtn("🎯 توزيع الدرجات تلقائيًا"){autoDistributeMarks()};addBtn("🔎 فحص الاختبار قبل الإخراج"){validateExam()};addBtn("📄 إخراج PDF"){pdf()};addBtn("🗎 إخراج ODT"){odt()};addBtn("🎲 نماذج A / B / C"){versions()};addBtn("⚙ إعدادات الورقة"){settings()};addBtn("🖨 طباعة الاختبار"){printExam()};addBtn("📝 ورقة إجابة للطالب"){answerSheetPdf()};addBtn("🖨 حفظ PDF ومشاركته"){pdf()};addBtn("🗂 النسخ الاحتياطي والاستعادة"){backupScreen()};addBtn("ℹ عن التطبيق"){about()}}

    private fun libraryScreen(){
        shell("الاختبارات المحفوظة")
        val raw=pref.getString("library","[]")?:"[]"
        val arr=try{JSONArray(raw)}catch(e:Exception){JSONArray()}
        if(arr.length()==0) info("لا توجد اختبارات محفوظة بعد. استخدم حفظ الاختبار باسم من شاشة الإدارة.")
        for(i in 0 until arr.length()){
            val item=arr.getJSONObject(i)
            val name=item.optString("name","اختبار")
            val stamp=item.optString("stamp","")
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
            row.addView(TextView(this).apply{text="$name\n$stamp";textSize=16f;gravity=Gravity.RIGHT;setPadding(8,8,8,8)},LinearLayout.LayoutParams(0,-2,1f))
            row.addView(btn("📂 فتح"){loadLibraryItem(item);Toast.makeText(this,"تم فتح: $name",Toast.LENGTH_SHORT).show();home()})
            row.addView(btn("🗑"){arr.remove(i);pref.edit().putString("library",arr.toString()).apply();libraryScreen()})
            root.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,5,0,5)})
        }
        addBtn("💾 حفظ الاختبار الحالي باسم"){saveToLibrary()};addBtn("📤 تصدير الاختبار الحالي JSON"){exportCurrentExam()};addBtn("📋 إنشاء نسخة من الاختبار"){duplicateCurrentExam()}
        addBtn("📥 استيراد اختبار من ملف JSON"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json"},701)}
        addBtn("↩ الرئيسية"){home()}
    }

    private fun snapshot():JSONObject{
        val o=JSONObject();o.put("school",school);o.put("teacher",teacher);o.put("subject",subject);o.put("grade",grade);o.put("title",title);o.put("sectionTitle",sectionTitle);o.put("instructions",instructions);o.put("examDuration",examDuration);o.put("logoUri",logoUri);o.put("term",term);o.put("academicYear",academicYear);o.put("watermark",watermark);o.put("examDuration",examDuration);o.put("logoUri",logoUri);o.put("exam",JSONArray().also{a->qs.forEach{a.put(qToJson(it))}});return o
    }

    private fun loadLibraryItem(o:JSONObject){
        school=o.optString("school",school);teacher=o.optString("teacher",teacher);subject=o.optString("subject",subject);grade=o.optString("grade",grade);title=o.optString("title",title);sectionTitle=o.optString("sectionTitle",sectionTitle);instructions=o.optString("instructions",instructions);examDuration=o.optString("examDuration",examDuration);logoUri=o.optString("logoUri",logoUri);term=o.optString("term",term);academicYear=o.optString("academicYear",academicYear);watermark=o.optString("watermark",watermark);qs.clear();o.optJSONArray("exam")?.let{a->for(i in 0 until a.length())qs.add(qFromJson(a.getJSONObject(i)))};saveMeta()
    }

    private fun saveToLibrary(){
        if(qs.isEmpty()){Toast.makeText(this,"أضف أسئلة قبل حفظ الاختبار",Toast.LENGTH_LONG).show();return}
        val edit=EditText(this).apply{setText(title);hint="اسم الاختبار المحفوظ";gravity=Gravity.RIGHT;setPadding(16,8,16,8)}
        AlertDialog.Builder(this).setTitle("حفظ الاختبار في المكتبة").setView(edit).setPositiveButton("حفظ"){_,_->
            val name=edit.text.toString().trim().ifBlank{"اختبار ${school.ifBlank{"الوصابي"}}"}
            val arr=try{JSONArray(pref.getString("library","[]"))}catch(e:Exception){JSONArray()}
            val item=snapshot().apply{put("name",name);put("stamp",java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",java.util.Locale.getDefault()).format(java.util.Date()))}
            arr.put(item);pref.edit().putString("library",arr.toString()).apply();Toast.makeText(this,"تم حفظ الاختبار في المكتبة",Toast.LENGTH_LONG).show()
        }.setNegativeButton("إلغاء",null).show()
    }

    private fun duplicateCurrentExam(){
        if(qs.isEmpty()){Toast.makeText(this,"لا يوجد اختبار لنسخه",Toast.LENGTH_LONG).show();return}
        title=if(title.contains("نسخة")) title else "$title — نسخة"
        qs.forEach{it.text=it.text.trim()}
        saveMeta();Toast.makeText(this,"تم إنشاء نسخة قابلة للتعديل",Toast.LENGTH_SHORT).show();editor()
    }

    private fun applyTemplate(o:JSONObject){
        school=o.optString("school",school);teacher=o.optString("teacher",teacher);subject=o.optString("subject",subject);grade=o.optString("grade",grade);sectionTitle=o.optString("sectionTitle",sectionTitle);instructions=o.optString("instructions",instructions);examDuration=o.optString("examDuration",examDuration);logoUri=o.optString("logoUri",logoUri);term=o.optString("term",term);academicYear=o.optString("academicYear",academicYear);watermark=o.optString("watermark",watermark);showBoxes=o.optBoolean("showBoxes",showBoxes);showPageNumbers=o.optBoolean("showPageNumbers",showPageNumbers);pageOrientation=o.optString("pageOrientation",pageOrientation);renderFontSize=o.optDouble("renderFontSize",renderFontSize.toDouble()).toFloat();pageMargin=o.optDouble("pageMargin",pageMargin.toDouble()).toFloat();lineSpacing=o.optDouble("lineSpacing",lineSpacing.toDouble()).toFloat();showPageBorder=o.optBoolean("showPageBorder",showPageBorder);footerText=o.optString("footerText",footerText)
    }

    private fun templatesScreen(){
        shell("قوالب الاختبارات")
        info("القالب يحفظ بيانات الورقة وإعداداتها وبنية الاختبار لتبدأ منه اختبارًا جديدًا.")
        val arr=try{JSONArray(pref.getString("templates","[]"))}catch(e:Exception){JSONArray()}
        if(arr.length()==0) info("لا توجد قوالب محفوظة بعد.")
        for(i in 0 until arr.length()){
            val o=arr.getJSONObject(i); val name=o.optString("name","قالب")
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
            row.addView(TextView(this).apply{text=name;textSize=16f;gravity=Gravity.RIGHT;setPadding(8,8,8,8)},LinearLayout.LayoutParams(0,-2,1f))
            row.addView(btn("📂 استخدام"){applyTemplate(o);title="اختبار جديد — $name";qs.clear();saveMeta();home()})
            row.addView(btn("🗑"){arr.remove(i);pref.edit().putString("templates",arr.toString()).apply();templatesScreen()})
            root.addView(row)
        }
        addBtn("➕ حفظ الاختبار الحالي كقالب"){
            if(qs.isEmpty()){Toast.makeText(this,"أضف أسئلة أولًا",Toast.LENGTH_LONG).show();return@addBtn}
            val e=EditText(this).apply{hint="اسم القالب";gravity=Gravity.RIGHT}
            AlertDialog.Builder(this).setTitle("حفظ قالب").setView(e).setPositiveButton("حفظ"){_,_->
                val name=e.text.toString().trim().ifBlank{"قالب ${subject.ifBlank{"عام"}}"}
                val item=snapshot().apply{put("name",name);put("exam",JSONArray())}
                arr.put(item);pref.edit().putString("templates",arr.toString()).apply();Toast.makeText(this,"تم حفظ القالب",Toast.LENGTH_SHORT).show();templatesScreen()
            }.setNegativeButton("إلغاء",null).show()
        }
        addBtn("📤 تصدير القوالب"){val out=JSONArray();for(i in 0 until arr.length())out.put(arr.getJSONObject(i));chooseSave(out.toString(2).toByteArray(Charsets.UTF_8),"application/json","قوالب_الوصابي.json")}
        addBtn("📥 استيراد القوالب"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json"},705)}
        addBtn("↩ الرئيسية"){home()}
    }

    private fun restoreExamJson(o:JSONObject){
        school=o.optString("school",school);teacher=o.optString("teacher",teacher);subject=o.optString("subject",subject);grade=o.optString("grade",grade);title=o.optString("title",title);sectionTitle=o.optString("sectionTitle",sectionTitle);instructions=o.optString("instructions",instructions);examDuration=o.optString("examDuration",examDuration);logoUri=o.optString("logoUri",logoUri);term=o.optString("term",term);academicYear=o.optString("academicYear",academicYear);watermark=o.optString("watermark",watermark)
        qs.clear();o.optJSONArray("exam")?.let{a->for(i in 0 until a.length())qs.add(qFromJson(a.getJSONObject(i)))}
        saveMeta()
    }

    private fun answerKeyPdf(){
        if(qs.isEmpty()){Toast.makeText(this,"لا توجد أسئلة",Toast.LENGTH_LONG).show();return}
        val doc=PdfDocument(); val w=595; val h=842; var pageNo=0; var page:PdfDocument.Page?=null; var canvas:Canvas?=null; var y=45f; val margin=38f
        val paint=TextPaint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=14f}; val bold=TextPaint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=16f;typeface=Typeface.DEFAULT_BOLD}
        fun start(){pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(w,h,pageNo).create());canvas=page!!.canvas;y=45f}
        fun finish(){canvas?.drawText("مفتاح الإجابة — صفحة $pageNo",w/2f-75f,h-24f,Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.DKGRAY;textSize=9f});doc.finishPage(page!!);page=null;canvas=null}
        fun block(t:String,b:Boolean=false){val tp=if(b)bold else paint;val sl=StaticLayout.Builder.obtain(t,tp,w-2*margin.toInt()).setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setTextDirection(TextDirectionHeuristics.RTL).setIncludePad(false).build();if(y+sl.height>h-50){finish();start()};canvas!!.save();canvas!!.translate(margin,y);sl.draw(canvas!!);canvas!!.restore();y+=sl.height+8}
        start();block(title,true);block("المادة: $subject    الصف: $grade");block("إجمالي الدرجات: ${totalMarks()}");qs.forEachIndexed{i,q->block("${i+1}. ${q.answer.ifBlank{"—"}}    (${q.marks} درجة)")};block(watermark)
        finish();val out=ByteArrayOutputStream();doc.writeTo(out);doc.close();chooseSave(out.toByteArray(),"application/pdf","مفتاح_إجابة_الوصابي.pdf")
    }

    private fun editor(){shell("بيانات الاختبار");root.addView(input("اسم المدرسة",school){school=it});root.addView(input("اسم المعلم",teacher){teacher=it});root.addView(input("المادة",subject){subject=it});root.addView(input("الصف",grade){grade=it});root.addView(input("عنوان الاختبار",title){title=it});root.addView(input("عنوان القسم / الجزء (اختياري)",sectionTitle){sectionTitle=it});root.addView(input("تعليمات الاختبار (اختياري)",instructions){instructions=it});root.addView(input("زمن الاختبار (اختياري)",examDuration){examDuration=it});root.addView(input("الفصل الدراسي",term){term=it});root.addView(input("العام الدراسي",academicYear){academicYear=it});addBtn("🎓 اختيار الصف والمادة من القائمة"){curriculumPicker()};addBtn("➕ صح / خطأ"){addQ("صح / خطأ")};addBtn("➕ اختيار من متعدد"){addQ("اختيار من متعدد")};addBtn("➕ أكمل الفراغ"){addQ("أكمل")};addBtn("➕ تعريف / مصطلح"){addQ("تعريف")};addBtn("➕ اشرح / وضّح"){addQ("اشرح")};addBtn("➕ علل / لماذا"){addQ("علل")};addBtn("➕ قارن"){addQ("قارن")};addBtn("➕ مسألة / احسب"){addQ("مسألة")};addBtn("➕ رتب / صِل"){addQ("ترتيب / وصل")};addBtn("➕ سؤال مقالي"){addQ("مقالي")};addBtn("➕ معادلة / صيغة"){addQ("معادلة")};addBtn("💾 حفظ"){saveMeta();Toast.makeText(this,"تم الحفظ",Toast.LENGTH_SHORT).show()};addBtn("📝 إدارة الأسئلة"){manager()};addBtn("📊 جدول مواصفات الاختبار"){specTable()};addBtn("🩺 فحص نهائي للاختبار"){finalCheck()};addBtn("↩ الرئيسية"){saveMeta();home()}}
    private fun addQ(type:String){val q=Q(type);if(type=="اختيار من متعدد")q.options.addAll(listOf("","","",""));qs.add(q);saveExam();manager()}

    private fun manager(){shell("إدارة الأسئلة — ${qs.size} سؤال");if(qs.isEmpty())info("لا توجد أسئلة بعد. أضف سؤالًا من شاشة إنشاء الاختبار.")
        qs.forEachIndexed{i,q->val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(8,10,8,10);setBackgroundColor(Color.WHITE)};box.addView(TextView(this).apply{text="${i+1}. ${q.type}";textSize=17f;setTypeface(Typeface.DEFAULT,Typeface.BOLD);gravity=Gravity.RIGHT});box.addView(input("نص السؤال",q.text){q.text=it},LinearLayout.LayoutParams(-1,90));box.addView(input("الدرجة",q.marks){q.marks=it});box.addView(input("الوحدة / الدرس (اختياري)",q.unit){q.unit=it});box.addView(TextView(this).apply{text=if(q.imageUri.isBlank())"🖼 لا توجد صورة للسؤال" else "🖼 تم إرفاق صورة للسؤال";textSize=14f;gravity=Gravity.RIGHT});box.addView(btn("🖼 إرفاق صورة للسؤال"){pendingQuestionIndex=i;startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*";addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)},704)});if(q.type=="اختيار من متعدد"){
            q.options.forEachIndexed{j,o->box.addView(input("الخيار ${('أ'.code+j).toChar()}",o){q.options[j]=it})}
            val labels=arrayOf("أ","ب","ج","د"); val ans=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,labels);setSelection(labels.indexOf(q.answer).coerceAtLeast(0));onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){ };override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){q.answer=labels[pos]}}};box.addView(TextView(this).apply{text="الإجابة الصحيحة";textSize=15f;gravity=Gravity.RIGHT});box.addView(ans)
        } else if(q.type=="صح / خطأ"){
            val labels=arrayOf("ص","خ"); val ans=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,labels);setSelection(labels.indexOf(q.answer).coerceAtLeast(0));onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){ };override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){q.answer=labels[pos]}}};box.addView(TextView(this).apply{text="الإجابة الصحيحة";textSize=15f;gravity=Gravity.RIGHT});box.addView(ans)
        } else box.addView(input("الإجابة النموذجية",q.answer){q.answer=it});box.addView(LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;addView(btn("⬆"){if(i>0){val x=qs.removeAt(i);qs.add(i-1,x);saveExam();manager()}},LinearLayout.LayoutParams(0,58,0.7f));addView(btn("⬇"){if(i<qs.lastIndex){val x=qs.removeAt(i);qs.add(i+1,x);saveExam();manager()}},LinearLayout.LayoutParams(0,58,0.7f));addView(btn("📋 نسخ"){qs.add(i+1,cloneQ(q));saveExam();manager()},LinearLayout.LayoutParams(0,58,1f));addView(btn("🗑 حذف"){qs.removeAt(i);saveExam();manager()},LinearLayout.LayoutParams(0,58,1f))});root.addView(box,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,6,0,6)})}
        addBtn("➕ إضافة سؤال"){editor()};addBtn("📚 إضافة من بنك الأسئلة"){bankScreen()};addBtn("💾 حفظ الاختبار في المكتبة"){saveToLibrary()};addBtn("💾 حفظ في بنك الأسئلة"){val added=addToBankUnique(qs);Toast.makeText(this,"تمت إضافة $added سؤالًا جديدًا إلى البنك",Toast.LENGTH_SHORT).show()};addBtn("✅ مفتاح الإجابة"){answerKey()};addBtn("↩ الرئيسية"){home()}}

    private fun bankScreen(){
        shell("بنك الأسئلة — ${bank.size}")
        val search=input("بحث في نص السؤال أو الوحدة أو النوع",""){renderBank(it)};root.addView(search)
        val types=arrayOf("كل الأنواع","صح / خطأ","اختيار من متعدد","أكمل","تعريف","اشرح","علل","قارن","مسألة","ترتيب / وصل","مقالي","معادلة")
        val type=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,types)};root.addView(type)
        val unit=input("تصفية حسب الوحدة / الدرس (اختياري)",""){renderBank(search.text.toString())};root.addView(unit)
        unit.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){renderBank(search.text.toString())};override fun afterTextChanged(e:Editable?){}})
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(list)
        fun draw(filter:String){
            list.removeAllViews(); val selected=type.selectedItem?.toString()?:(types[0]); val u=unit.text.toString().trim()
            bank.forEachIndexed{i,q->{val okText=filter.isBlank()||q.text.contains(filter,true)||q.type.contains(filter,true)||q.unit.contains(filter,true);val okType=selected==types[0]||q.type==selected;val okUnit=u.isBlank()||q.unit.contains(u,true);if(okText&&okType&&okUnit){
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
                row.addView(TextView(this).apply{text="${i+1}. ${q.type}: ${q.text}${if(q.unit.isBlank())"" else "
الوحدة: ${q.unit}"}";textSize=15f;gravity=Gravity.RIGHT},LinearLayout.LayoutParams(0,-2,1f))
                row.addView(btn("➕"){qs.add(cloneQ(q));saveExam();Toast.makeText(this,"تمت إضافة السؤال",Toast.LENGTH_SHORT).show()})
                row.addView(btn("🗑"){bank.removeAt(i);saveBank();bankScreen()});list.addView(row)
            }}}
        }
        renderBank={x->draw(x)};type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){draw(search.text.toString())}}
        draw("")
        addBtn("📤 تصدير بنك الأسئلة"){exportBank()};addBtn("📥 استيراد بنك الأسئلة"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json"},703)}
        addBtn("↩ إدارة الاختبار"){manager()}
    }
    private var renderBank:(String)->Unit = {}


    private fun exportCurrentExam(){
        val o=snapshot()
        o.put("app","محرر الوصابي الشامل")
        o.put("version","4.0")
        chooseSave(o.toString(2).toByteArray(Charsets.UTF_8),"application/json","اختبار_${title.ifBlank{"بدون_عنوان"}}.json")
    }

    private fun exportBank(){val a=JSONArray();bank.forEach{a.put(qToJson(it))};chooseSave(a.toString(2).toByteArray(Charsets.UTF_8),"application/json","بنك_الأسئلة.json")}
    private fun examBlueprint(){
        shell("مخطط الاختبار الذكي")
        info("حدد عدد الأسئلة من كل نوع. سيستخدم التطبيق أسئلة فريدة من بنك الأسئلة، ولن يخلط الأنواع إذا كان العدد المطلوب متاحًا.")
        val types=arrayOf("صح / خطأ","اختيار من متعدد","أكمل","تعريف","اشرح","علل","قارن","مسألة","ترتيب / وصل","مقالي","معادلة")
        val fields=linkedMapOf<String,EditText>()
        types.forEach{t-> val e=input("$t — العدد","0"){}; fields[t]=e; root.addView(e) }
        addBtn("⚡ إنشاء الاختبار حسب المخطط"){
            val plan=fields.mapValues{it.value.text.toString().toIntOrNull()?:0}
            val requested=plan.values.sum()
            if(requested<=0){Toast.makeText(this,"حدد عددًا واحدًا على الأقل",Toast.LENGTH_LONG).show();return@addBtn}
            val available=bank.groupBy{it.type}
            val missing=plan.filter{(t,n)->n>0 && (available[t]?.size?:0)<n}
            if(missing.isNotEmpty()){
                val msg=missing.entries.joinToString("\n"){ "${it.key}: المطلوب ${it.value} والمتاح ${available[it.key]?.size?:0}" }
                AlertDialog.Builder(this).setTitle("الأسئلة غير كافية").setMessage(msg).setPositiveButton("حسنًا",null).show()
                return@addBtn
            }
            qs.clear()
            plan.forEach{(t,n)-> if(n>0) qs.addAll((available[t]?:emptyList()).shuffled().take(n).map{cloneQ(it)})}
            qs.shuffle()
            saveExam()
            Toast.makeText(this,"تم إنشاء اختبار من $requested سؤالًا",Toast.LENGTH_LONG).show()
            manager()
        }
        addBtn("↩ الرئيسية"){home()}
    }

    private fun autoGenerate(){shell("مولّد الاختبار التلقائي");info("اختر العدد والنوع. سيحاول المولد توزيع الأسئلة على الأنواع المتاحة، ثم يكمل عشوائيًا إذا لزم الأمر.");val count=input("عدد الأسئلة",minOf(10,bank.size).coerceAtLeast(1).toString()){};root.addView(count);val type=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("كل الأنواع","صح / خطأ","اختيار من متعدد","أكمل","تعريف","اشرح","علل","قارن","مسألة","ترتيب / وصل","مقالي","معادلة"))};root.addView(type);addBtn("⚡ توليد الآن"){val n=count.text.toString().toIntOrNull()?:0;if(n<=0||bank.isEmpty()){Toast.makeText(this,"أضف أسئلة إلى البنك أولًا",Toast.LENGTH_LONG).show();return@addBtn};val selected=type.selectedItem.toString();val pool=if(selected=="كل الأنواع") bank else bank.filter{it.type==selected};if(pool.isEmpty()){Toast.makeText(this,"لا توجد أسئلة من هذا النوع في البنك",Toast.LENGTH_LONG).show();return@addBtn};qs.clear();qs.addAll(pool.shuffled().take(n).map{cloneQ(it)});if(qs.size<n)qs.addAll((bank-sharedItems(qs,bank)).shuffled().take(n-qs.size).map{cloneQ(it)});saveExam();Toast.makeText(this,"تم توليد ${qs.size} سؤالًا",Toast.LENGTH_SHORT).show();manager()};addBtn("↩ الرئيسية"){home()}}
    private fun sharedItems(current:List<Q>, source:List<Q>):List<Q>{val used=current.map{it.text}.toSet();return source.filter{it.text in used}}

    private fun autoDistributeMarks(){
        shell("توزيع الدرجات تلقائيًا")
        if(qs.isEmpty()){info("لا توجد أسئلة في الاختبار.");addBtn("↩ الرئيسية"){home()};return}
        info("حدد الدرجة الكلية للاختبار، وسيتم توزيعها بالتساوي على الأسئلة مع ضبط الفارق إلى درجة واحدة عند الحاجة.")
        val total=input("الدرجة الكلية المطلوبة",totalMarks().coerceAtLeast(qs.size).toString()){};root.addView(total)
        addBtn("🎯 توزيع الدرجات"){
            val target=total.text.toString().toIntOrNull()?:0
            if(target<qs.size){Toast.makeText(this,"الدرجة الكلية يجب أن تكون على الأقل ${qs.size} (درجة واحدة لكل سؤال)",Toast.LENGTH_LONG).show();return@addBtn}
            val base=target/qs.size; var extra=target%qs.size
            qs.forEach{q->q.marks=(base + if(extra>0){extra--;1}else 0).toString()}
            saveExam()
            Toast.makeText(this,"تم توزيع $target درجة على ${qs.size} سؤالًا",Toast.LENGTH_LONG).show()
            manager()
        }
        addBtn("↩ الرئيسية"){home()}
    }

    private fun validateExam(){
        shell("فحص الاختبار")
        if(qs.isEmpty()){info("لا توجد أسئلة في الاختبار.");addBtn("↩ الرئيسية"){home()};return}
        val problems=mutableListOf<String>()
        qs.forEachIndexed{i,q->
            if(q.text.isBlank()) problems.add("السؤال ${i+1}: نص السؤال فارغ")
            val m=q.marks.toIntOrNull()
            if(m==null||m<=0) problems.add("السؤال ${i+1}: الدرجة يجب أن تكون رقمًا أكبر من صفر")
            if(q.type=="اختيار من متعدد" && q.options.count{it.isNotBlank()}<2) problems.add("السؤال ${i+1}: يحتاج خيارين على الأقل")
            if(q.type=="اختيار من متعدد" && q.answer.isBlank()) problems.add("السؤال ${i+1}: لم تُحدد الإجابة النموذجية")
            if(q.type=="صح / خطأ" && q.answer.isBlank()) problems.add("السؤال ${i+1}: حدد الإجابة الصحيحة (ص أو خ)")
        }
        if(problems.isEmpty()) info("✓ الاختبار سليم مبدئيًا

عدد الأسئلة: ${qs.size}
إجمالي الدرجات: ${totalMarks()}

يمكنك الآن المعاينة أو الإخراج إلى PDF / ODT أو الطباعة.")
        else {info("تم العثور على ${problems.size} ملاحظة:

"+problems.joinToString("\n"))}
        addBtn("📝 إدارة الأسئلة"){manager()};addBtn("📊 جدول مواصفات الاختبار"){specTable()};addBtn("🩺 فحص نهائي للاختبار"){finalCheck()};addBtn("👁 المعاينة"){preview()};addBtn("↩ الرئيسية"){home()}
    }

    private fun statistics(){
        shell("إحصاءات الاختبار")
        val counts=qs.groupingBy{it.type}.eachCount()
        info("عدد الأسئلة: ${qs.size}\nإجمالي الدرجات: ${totalMarks()}\n\n" + listOf("صح / خطأ","اختيار من متعدد","أكمل","تعريف","اشرح","علل","قارن","مسألة","ترتيب / وصل","مقالي","معادلة").joinToString("\n"){ "${it}: ${counts[it]?:0}" })
        addBtn("↩ الرئيسية"){home()}
    }

    private fun markStatistics(){shell("توزيع الدرجات حسب النوع");val groups=qs.groupBy{it.type};if(groups.isEmpty())info("لا توجد أسئلة");else groups.entries.sortedBy{it.key}.forEach{(type,list)->info("$type: ${list.sumOf{it.marks.toIntOrNull()?:0}} درجة — ${list.size} سؤال")};info("الإجمالي: ${totalMarks()} درجة");addBtn("↩ الرئيسية"){home()}}

    private fun specTable(){
        shell("جدول مواصفات الاختبار")
        if(qs.isEmpty()){info("لا توجد أسئلة لإنشاء جدول المواصفات.");addBtn("↩ الرئيسية"){home()};return}
        val byType=linkedMapOf<String,MutableList<Q>>()
        qs.forEach{byType.getOrPut(it.type){mutableListOf()}.add(it)}
        info("يوضح الجدول عدد الأسئلة والدرجات ونسبة كل نوع من إجمالي الاختبار.")
        val total=totalMarks().coerceAtLeast(1)
        byType.forEach{(type,list)->
            val marks=list.sumOf{it.marks.toIntOrNull()?:0}
            val pct=marks*100.0/total
            root.addView(TextView(this).apply{text="$type  |  عدد: ${list.size}  |  الدرجات: $marks  |  النسبة: ${String.format("%.1f",pct)}%";textSize=16f;gravity=Gravity.RIGHT;setPadding(12,12,12,12);setBackgroundColor(Color.WHITE)})
        }
        info("الإجمالي: ${qs.size} سؤال — $total درجة")
        addBtn("↩ الرئيسية"){home()}
    }

    private fun finalCheck(){
        shell("الفحص النهائي للاختبار")
        var errors=0
        qs.forEachIndexed{i,q->
            val n=i+1
            if(q.text.trim().isEmpty()){info("❌ السؤال $n: نص السؤال فارغ");errors++}
            if((q.marks.toIntOrNull()?:0)<=0){info("❌ السؤال $n: الدرجة غير صحيحة");errors++}
            if(q.type=="اختيار من متعدد") {
                val filled=q.options.count{it.trim().isNotEmpty()}
                if(filled<2){info("❌ السؤال $n: يحتاج خيارين على الأقل");errors++}
                if(q.answer.isBlank()){info("⚠️ السؤال $n: لم تحدد الإجابة الصحيحة")}
            }
            if(q.type=="صح / خطأ" && q.answer.isBlank()) info("⚠️ السؤال $n: لم تحدد إجابة صح/خطأ")
        }
        if(qs.isEmpty()){info("❌ الاختبار لا يحتوي على أسئلة");errors++}
        if(errors==0) info("✅ لم يتم العثور على أخطاء أساسية. الاختبار جاهز للمعاينة والإخراج.") else info("عدد الأخطاء الأساسية: $errors")
        addBtn("↩ الرئيسية"){home()}
    }

    private fun answerKey(){shell("مفتاح الإجابة");if(qs.isEmpty())info("لا توجد أسئلة");qs.forEachIndexed{i,q->root.addView(TextView(this).apply{text="${i+1}. ${q.answer.ifBlank{"—"}}    (${q.marks} درجة)";textSize=16f;gravity=Gravity.RIGHT;setPadding(8,8,8,8)})};addBtn("↩ الرئيسية"){home()}}

    private fun versions(){shell("نماذج A / B / C");info("إنشاء ثلاثة نماذج بترتيبات مختلفة للأسئلة.");addBtn("🎲 إنشاء النماذج"){listOf("A","B","C").forEach{saveList("version_$it",qs.map{q->cloneQ(q)}.shuffled())};Toast.makeText(this,"تم إنشاء النماذج A وB وC",Toast.LENGTH_SHORT).show()};addBtn("عرض A"){loadVersion("A")};addBtn("عرض B"){loadVersion("B")};addBtn("عرض C"){loadVersion("C")};addBtn("↩ الرئيسية"){home()}}
    private fun loadVersion(name:String){val temp=mutableListOf<Q>();loadList("version_$name",temp);qs.clear();qs.addAll(temp);preview("النموذج $name")}

    private fun preview(extra:String=""){shell("معاينة ورقة الاختبار");val head=if(extra.isBlank())title else "$title — $extra";root.addView(TextView(this).apply{text="$school\n$teacher\nالمادة: $subject     الصف: $grade\nالفصل: $term     العام: $academicYear\n$head";textSize=18f;gravity=Gravity.CENTER;setPadding(8,18,8,18)});qs.forEachIndexed{i,q->val s=StringBuilder("${i+1}. ${q.text}   (${q.marks})\n");when(q.type){"صح / خطأ"->s.append("☐ ص       ☐ خ");"اختيار من متعدد"->q.options.forEachIndexed{j,o->s.append("${('أ'.code+j).toChar()}) $o    ")}};root.addView(TextView(this).apply{text=s.toString();textSize=16f;gravity=Gravity.RIGHT;setPadding(10,10,10,10);setBackgroundColor(Color.WHITE)});if(q.imageUri.isNotBlank()){try{contentResolver.openInputStream(Uri.parse(q.imageUri))?.use{stream->BitmapFactory.decodeStream(stream)?.let{bm->root.addView(ImageView(this).apply{setImageBitmap(bm);adjustViewBounds=true;maxHeight=500;setPadding(10,4,10,8)})}}}catch(_:Exception){}}};root.addView(TextView(this).apply{text="\n$watermark";textSize=13f;gravity=Gravity.CENTER});addBtn("↩ الرئيسية"){home()}}

    private fun chooseLogo(){
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*";addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)},702)
    }

    private fun settings(){shell("تصميم الورقة");root.addView(input("العلامة المائية",watermark){watermark=it});root.addView(input("زمن الاختبار",examDuration){examDuration=it});addBtn("🖼 اختيار شعار المدرسة"){chooseLogo()};info(if(logoUri.isBlank())"لم يتم اختيار شعار." else "تم اختيار شعار للورقة.");root.addView(input("حجم خط PDF",renderFontSize.toString()){renderFontSize=it.toFloatOrNull()?.coerceIn(10f,24f)?:14f});root.addView(input("هوامش الصفحة (نقطة)",pageMargin.toString()){pageMargin=it.toFloatOrNull()?.coerceIn(20f,80f)?:38f});root.addView(input("تباعد الأسطر",lineSpacing.toString()){lineSpacing=it.toFloatOrNull()?.coerceIn(0f,12f)?:2f});root.addView(input("تذييل مخصص (اختياري)",footerText){footerText=it});val border=CheckBox(this).apply{text="إظهار إطار حول الصفحة";isChecked=showPageBorder;setOnCheckedChangeListener{_,v->showPageBorder=v}};root.addView(border);val boxes=CheckBox(this).apply{text="إظهار مربعات ترقيم الأسئلة";isChecked=showBoxes;setOnCheckedChangeListener{_,v->showBoxes=v}};root.addView(boxes);val pages=CheckBox(this).apply{text="إظهار أرقام الصفحات";isChecked=showPageNumbers;setOnCheckedChangeListener{_,v->showPageNumbers=v}};root.addView(pages);val orient=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("عمودي","أفقي"));setSelection(if(pageOrientation=="أفقي")1 else 0);onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){pageOrientation=if(pos==1)"أفقي" else "عمودي"}}};root.addView(TextView(this).apply{text="اتجاه الصفحة";textSize=16f;gravity=Gravity.RIGHT});root.addView(orient);info("PDF يدعم A4، الترويسة، التذييل، العلامة المائية، مربعات الترقيم، وترقيم الصفحات.");addBtn("💾 حفظ الإعدادات"){saveMeta();pref.edit().putBoolean("showBoxes",showBoxes).putBoolean("showPageNumbers",showPageNumbers).putString("pageOrientation",pageOrientation).putFloat("renderFontSize",renderFontSize).putFloat("pageMargin",pageMargin).putFloat("lineSpacing",lineSpacing).putBoolean("showPageBorder",showPageBorder).putString("footerText",footerText).putString("examDuration",examDuration).putString("logoUri",logoUri).apply();Toast.makeText(this,"تم الحفظ",Toast.LENGTH_SHORT).show()};addBtn("↩ الرئيسية"){home()}}

    private fun curriculumPicker(){
        val grades=arrayOf("الأول الأساسي","الثاني الأساسي","الثالث الأساسي","الرابع الأساسي","الخامس الأساسي","السادس الأساسي","السابع الأساسي","الثامن الأساسي","التاسع الأساسي","الأول الثانوي","الثاني الثانوي","الثالث الثانوي")
        val subjects=arrayOf("القرآن الكريم","التربية الإسلامية","اللغة العربية","اللغة الإنجليزية","الرياضيات","العلوم","الاجتماعيات","التاريخ","الجغرافيا","الفيزياء","الكيمياء","الأحياء","الحاسوب","الفلسفة والمنطق","علم النفس","علم الاجتماع","الاقتصاد","أخرى")
        AlertDialog.Builder(this).setTitle("اختر الصف").setItems(grades){_,which->grade=grades[which];AlertDialog.Builder(this).setTitle("اختر المادة").setItems(subjects){_,j->subject=subjects[j];saveMeta();editor()}.show()}.show()
    }

    private fun backupScreen(){
        shell("النسخ الاحتياطي والاستعادة")
        info("يمكنك حفظ الاختبارات وبنك الأسئلة والإعدادات في ملف واحد، ثم استعادته على الجهاز نفسه أو جهاز آخر.")
        addBtn("💾 إنشاء نسخة احتياطية"){backupExport()}
        addBtn("📥 استعادة نسخة احتياطية"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json"},700)}
        addBtn("🧹 حذف الاختبار الحالي"){qs.clear();saveExam();Toast.makeText(this,"تم حذف الاختبار الحالي",Toast.LENGTH_SHORT).show();home()}
        addBtn("🧹 حذف بنك الأسئلة"){bank.clear();saveBank();Toast.makeText(this,"تم حذف بنك الأسئلة",Toast.LENGTH_SHORT).show();home()}
        addBtn("↩ الرئيسية"){home()}
    }

    private fun backupExport(){
        val o=JSONObject();o.put("app","محرر الوصابي الشامل");o.put("version","4.0");o.put("school",school);o.put("teacher",teacher);o.put("subject",subject);o.put("grade",grade);o.put("title",title);o.put("term",term);o.put("academicYear",academicYear);o.put("watermark",watermark);o.put("sectionTitle",sectionTitle);o.put("instructions",instructions);o.put("examDuration",examDuration);o.put("logoUri",logoUri);o.put("exam",JSONArray().also{a->qs.forEach{a.put(qToJson(it))}});o.put("bank",JSONArray().also{a->bank.forEach{a.put(qToJson(it))}})
        chooseSave(o.toString(2).toByteArray(Charsets.UTF_8),"application/json","نسخة_احتياطية_الوصابي.json")
    }

    private fun restoreFromUri(uri:android.net.Uri){
        try{val text=contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use{it.readText()}?:return;val o=JSONObject(text);school=o.optString("school",school);teacher=o.optString("teacher",teacher);subject=o.optString("subject",subject);grade=o.optString("grade",grade);title=o.optString("title",title);term=o.optString("term",term);academicYear=o.optString("academicYear",academicYear);watermark=o.optString("watermark",watermark);sectionTitle=o.optString("sectionTitle",sectionTitle);instructions=o.optString("instructions",instructions);examDuration=o.optString("examDuration",examDuration);logoUri=o.optString("logoUri",logoUri);qs.clear();bank.clear();o.optJSONArray("exam")?.let{a->for(i in 0 until a.length())qs.add(qFromJson(a.getJSONObject(i)))};o.optJSONArray("bank")?.let{a->for(i in 0 until a.length())bank.add(qFromJson(a.getJSONObject(i)))};saveMeta();saveBank();Toast.makeText(this,"تمت استعادة النسخة الاحتياطية",Toast.LENGTH_LONG).show();home()}catch(e:Exception){Toast.makeText(this,"ملف النسخة الاحتياطية غير صالح",Toast.LENGTH_LONG).show()}
    }

    private fun about(){shell("عن التطبيق");info("محرر الوصابي الشامل\n\nإصدار 4.0\n\nأداة عربية لإعداد الاختبارات المدرسية وإدارتها وحفظها وإخراجها بصيغ PDF وODT.\n\nالعمل الأساسي لا يحتاج إلى اتصال بالإنترنت.");addBtn("↩ الرئيسية"){home()}}

    private fun drawRtl(c:Canvas,text:String,x:Float,y:Float,p:Paint){
        val tp=android.text.TextPaint(p)
        val sl=StaticLayout.Builder.obtain(text,tp,maxOf(1,(c.width-x).toInt()))
            .setAlignment(Layout.Alignment.ALIGN_OPPOSITE)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setIncludePad(false).build()
        c.save(); c.translate(x,y); sl.draw(c); c.restore()
    }
    private fun totalMarks():Int = qs.sumOf { it.marks.toIntOrNull() ?: 0 }

    private fun renderPdf(): Pair<ByteArray, Int> {
        val doc=PdfDocument()
        val landscape=pageOrientation=="أفقي"
        val pageW=if(landscape)842 else 595
        val pageH=if(landscape)595 else 842
        val margin=pageMargin
        val contentTop=42f
        val contentBottom=pageH-48f
        var pageNo=0
        var page: PdfDocument.Page?=null
        var canvas: Canvas?=null
        var y=contentTop
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=renderFontSize}
        val bold=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=renderFontSize;typeface=Typeface.DEFAULT_BOLD}
        val watermarkPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.GRAY;textSize=9f}
        val boxPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.rgb(224,239,250);style=Paint.Style.FILL}
        val logo: Bitmap? = try { if(logoUri.isBlank()) null else contentResolver.openInputStream(Uri.parse(logoUri))?.use{BitmapFactory.decodeStream(it)} } catch(_:Exception){null}

        fun startPage(){
            pageNo++
            page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create())
            canvas=page!!.canvas
            y=contentTop
            if(logo!=null){
                val max=64f; val scale=minOf(max/logo.width.toFloat(),max/logo.height.toFloat()); val bw=(logo.width*scale).toInt(); val bh=(logo.height*scale).toInt(); val left=pageW-margin-bw; canvas!!.drawBitmap(logo,null,RectF(left,8f,left+bw,8f+bh),Paint(Paint.ANTI_ALIAS_FLAG)); y=maxOf(y,8f+bh+8f)
            }
        }
        fun finishPage(){
            if(page!=null){
                watermarkPaint.alpha=150
                canvas!!.drawText(watermark,pageW-margin,pageH-22f,watermarkPaint)
                if(footerText.isNotBlank()){ val fp=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.DKGRAY;textSize=8f}; canvas!!.drawText(footerText,margin,pageH-22f,fp) }
                if(showPageBorder){ val bp=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.LTGRAY;style=Paint.Style.STROKE;strokeWidth=1f}; canvas!!.drawRect(18f,18f,pageW-18f,pageH-18f,bp) }
                if(showPageNumbers){
                    val pt=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.DKGRAY;textSize=9f}
                    canvas!!.drawText("صفحة $pageNo",pageW/2f-25f,pageH-22f,pt)
                }
                doc.finishPage(page)
                page=null;canvas=null
            }
        }
        fun layout(text:String,width:Int,boldText:Boolean=false): StaticLayout {
            val tp=TextPaint(Paint.ANTI_ALIAS_FLAG).apply{
                color=Color.BLACK
                textSize=renderFontSize
                typeface=if(boldText) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            }
            return StaticLayout.Builder.obtain(text,tp,width)
                .setAlignment(Layout.Alignment.ALIGN_OPPOSITE)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setIncludePad(false)
                .setLineSpacing(lineSpacing,1f)
                .build()
        }
        fun drawQuestionImage(uri:String){
            if(uri.isBlank()) return
            try{
                contentResolver.openInputStream(Uri.parse(uri))?.use{stream->
                    val bm=BitmapFactory.decodeStream(stream) ?: return
                    val maxW=pageW-2*margin; val maxH=180f
                    val scale=minOf(maxW/bm.width.toFloat(),maxH/bm.height.toFloat(),1f)
                    val bw=bm.width*scale; val bh=bm.height*scale
                    if(y+bh>contentBottom && y>contentTop){finishPage();startPage()}
                    canvas!!.drawBitmap(bm,null,RectF(margin,y,margin+bw,y+bh),Paint(Paint.ANTI_ALIAS_FLAG))
                    y+=bh+8f
                }
            }catch(_:Exception){}
        }
        fun drawTextBlock(text:String,boldText:Boolean=false,indent:Int=0):Float {
            val width=pageW-(margin*2).toInt()-indent
            val sl=layout(text,width,boldText)
            if(y+sl.height>contentBottom && y>contentTop){ finishPage(); startPage() }
            canvas!!.save()
            canvas!!.translate(margin+indent,y)
            sl.draw(canvas!!)
            canvas!!.restore()
            y+=sl.height+7f
            return sl.height.toFloat()
        }

        startPage()
        drawTextBlock(school,true)
        drawTextBlock(teacher)
        val meta=listOf(
            if(subject.isNotBlank()) "المادة: $subject" else "",
            if(grade.isNotBlank()) "الصف: $grade" else "",
            if(term.isNotBlank()) "الفصل: $term" else "",
            if(academicYear.isNotBlank()) "العام الدراسي: $academicYear" else "",
            if(examDuration.isNotBlank()) "الزمن: $examDuration" else ""
        ).filter{it.isNotBlank()}.joinToString("    ")
        if(meta.isNotBlank()) drawTextBlock(meta)
        drawTextBlock(title,true)
        if(instructions.isNotBlank()) drawTextBlock("التعليمات: $instructions")
        drawTextBlock("اسم الطالب: ______________________________    الصف/الشعبة: ______________")
        if(sectionTitle.isNotBlank()) drawTextBlock(sectionTitle,true)
        y+=5f

        qs.forEachIndexed{i,q->
            val qWidth=pageW-150
            val qLayout=layout(q.text.ifBlank{"(سؤال بلا نص)"},qWidth)
            val extra=if(q.type=="اختيار من متعدد") q.options.sumOf { layout(it.ifBlank{""},qWidth-20).height+4 } else 0
            val tfExtra=if(q.type=="صح / خطأ") 26 else 0
            val required=qLayout.height+extra+tfExtra+28
            if(y+required>contentBottom && y>contentTop){finishPage();startPage()}
            if(showBoxes){canvas!!.drawRoundRect(pageW-88f,y-3f,pageW-38f,y+23f,5f,5f,boxPaint)}
            canvas!!.drawText("${i+1}",pageW-70f,y+15f,bold)
            canvas!!.save();canvas!!.translate(margin,y);qLayout.draw(canvas!!);canvas!!.restore()
            y+=qLayout.height+5f
            if(q.type=="صح / خطأ"){
                drawTextBlock("☐ صـــــ   ☐ خـــــ")
            }
            if(q.type=="اختيار من متعدد"){
                q.options.forEachIndexed{j,o->
                    if(o.isBlank()) return@forEachIndexed
                    drawTextBlock("${('أ'.code+j).toChar()}) $o",false,12)
                }
            }
            if(q.type!="صح / خطأ" && q.type!="اختيار من متعدد") y+=4f
        }
        finishPage()
        val out=ByteArrayOutputStream();doc.writeTo(out);doc.close()
        return out.toByteArray() to pageNo
    }

    private fun printExam(){
        val pm=getSystemService(PRINT_SERVICE) as PrintManager
        pm.print("اختبار_الوصابي", object: PrintDocumentAdapter(){
            override fun onLayout(oldAttributes:PrintAttributes?,newAttributes:PrintAttributes?,cancellationSignal:CancellationSignal?,callback:LayoutResultCallback?,extras:Bundle?){
                if(cancellationSignal?.isCanceled==true){callback?.onLayoutCancelled();return}
                val pages=try{renderPdf().second}catch(e:Exception){1}
                callback?.onLayoutFinished(PrintDocumentInfo.Builder("اختبار_الوصابي.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(pages).build(),true)
            }
            override fun onWrite(pages:Array<out PageRange>?,destination:ParcelFileDescriptor?,cancellationSignal:CancellationSignal?,callback:WriteResultCallback?){
                try{
                    if(cancellationSignal?.isCanceled==true){callback?.onWriteCancelled();return}
                    val bytes=renderPdf().first
                    ParcelFileDescriptor.AutoCloseOutputStream(destination).use{it.write(bytes)}
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                }catch(e:Exception){callback?.onWriteFailed(e.message)}
            }
        },null)
    }

    private fun answerSheetPdf(){
        if(qs.isEmpty()){Toast.makeText(this,"لا توجد أسئلة",Toast.LENGTH_LONG).show();return}
        val doc=PdfDocument(); val w=595; val h=842; var pageNo=0; var page:PdfDocument.Page?=null; var canvas:Canvas?=null; var y=45f
        val margin=38f; val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK}; val titleP=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=18f;typeface=Typeface.DEFAULT_BOLD}
        fun start(){pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(w,h,pageNo).create());canvas=page!!.canvas;y=45f}
        fun finish(){canvas?.drawText("ورقة إجابة — $pageNo",w/2f-55f,h-24f,Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.DKGRAY;textSize=9f});doc.finishPage(page!!);page=null;canvas=null}
        fun text(t:String,size:Float=14f,bold:Boolean=false){val tp=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=size;typeface=if(bold)Typeface.DEFAULT_BOLD else Typeface.DEFAULT};val sl=StaticLayout.Builder.obtain(t,TextPaint(tp),w-2*margin.toInt()).setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setTextDirection(TextDirectionHeuristics.RTL).setIncludePad(false).build();if(y+sl.height>h-60){finish();start()};canvas!!.save();canvas!!.translate(margin,y);sl.draw(canvas!!);canvas!!.restore();y+=sl.height+10}
        start();text(title,18f,true);text("$school
$teacher
المادة: $subject     الصف: $grade
الاسم: ______________________________     الشعبة: __________",13f)
        qs.forEachIndexed{i,q->
            if(q.type=="اختيار من متعدد"){text("${i+1}. ${q.text}",13f);q.options.take(4).forEachIndexed{j,_ -> val x=margin+80+j*105; val yy=y+12; canvas!!.drawCircle(x,yy,8f,p); canvas!!.drawText(('أ'.code+j).toChar().toString(),x-4,yy+4,p)}; y+=30}
            } else if(q.type=="صح / خطأ"){text("${i+1}. ${q.text}      ☐ ص       ☐ خ",13f)} else {text("${i+1}. ${q.text}
الإجابة: ______________________________________________",13f)}
        }
        text("إجمالي الدرجات: ${totalMarks()}
$watermark",11f);finish();val out=ByteArrayOutputStream();doc.writeTo(out);doc.close();chooseSave(out.toByteArray(),"application/pdf","ورقة_إجابة_الطالب_الوصابي.pdf")
    }

    private fun pdf(){
        try{
            val bytes=renderPdf().first
            chooseSave(bytes,"application/pdf","اختبار_الوصابي.pdf")
        }catch(e:Exception){Toast.makeText(this,"تعذر إنشاء PDF: ${e.message}",Toast.LENGTH_LONG).show()}
    }

    private fun xmlEsc(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;")
    private fun odt(){val body=StringBuilder();body.append("<text:p text:style-name=\"Title\">${xmlEsc(title)}</text:p>");if(sectionTitle.isNotBlank())body.append("<text:p>${xmlEsc(sectionTitle)}</text:p>");body.append("<text:p>${xmlEsc(school)}</text:p><text:p>${xmlEsc(teacher)}</text:p><text:p>التعليمات: ${xmlEsc(instructions)}</text:p><text:p>اسم الطالب: ______________________________ — المادة: ${xmlEsc(subject)} — الصف: ${xmlEsc(grade)} — الفصل: ${xmlEsc(term)} — العام: ${xmlEsc(academicYear)} — الزمن: ${xmlEsc(examDuration)}</text:p>");qs.forEachIndexed{i,q->{body.append("<text:p>${i+1}. ${xmlEsc(q.text)} (${xmlEsc(q.marks)})${if(q.unit.isBlank()) "" else " — ${xmlEsc(q.unit)}"}</text:p>");if(q.type=="صح / خطأ")body.append("<text:p>☐ ص     ☐ خ</text:p>");q.options.forEachIndexed{j,o->body.append("<text:p>${('أ'.code+j).toChar()}) ${xmlEsc(o)}</text:p>")}};body.append("<text:p>${xmlEsc(watermark)}</text:p>")
        val content="""<?xml version="1.0" encoding="UTF-8"?><office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" office:version="1.2"><office:automatic-styles><style:style style:name="Title" style:family="paragraph"><style:text-properties fo:font-size="16pt"/></style:style></office:automatic-styles><office:body><office:text>$body</office:text></office:body></office:document-content>"""
        val styles="""<?xml version="1.0" encoding="UTF-8"?><office:document-styles xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" office:version="1.2"><office:styles/></office:document-styles>"""
        val manifest="""<?xml version="1.0" encoding="UTF-8"?><manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2"><manifest:file-entry manifest:media-type="application/vnd.oasis.opendocument.text" manifest:full-path="/"/><manifest:file-entry manifest:media-type="text/xml" manifest:full-path="content.xml"/><manifest:file-entry manifest:media-type="text/xml" manifest:full-path="styles.xml"/></manifest:manifest>"""
        val out=ByteArrayOutputStream();ZipOutputStream(out).use{z->z.putNextEntry(ZipEntry("mimetype"));z.write("application/vnd.oasis.opendocument.text".toByteArray());z.closeEntry();z.putNextEntry(ZipEntry("content.xml"));z.write(content.toByteArray());z.closeEntry();z.putNextEntry(ZipEntry("styles.xml"));z.write(styles.toByteArray());z.closeEntry();z.putNextEntry(ZipEntry("META-INF/manifest.xml"));z.write(manifest.toByteArray());z.closeEntry()};chooseSave(out.toByteArray(),"application/vnd.oasis.opendocument.text","اختبار_الوصابي.odt")}

    private fun chooseSave(bytes:ByteArray,mime:String,name:String){pending=bytes;pendingMime=mime;pendingName=name;startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type=mime;putExtra(Intent.EXTRA_TITLE,name)},500)}
    override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==704&&c==RESULT_OK&&d?.data!=null&&pendingQuestionIndex in qs.indices){try{contentResolver.takePersistableUriPermission(d.data!!,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){};qs[pendingQuestionIndex].imageUri=d.data!!.toString();saveExam();pendingQuestionIndex=-1;Toast.makeText(this,"تم إرفاق صورة السؤال",Toast.LENGTH_SHORT).show();manager();return};if(r==702&&c==RESULT_OK&&d?.data!=null){try{contentResolver.takePersistableUriPermission(d.data!!,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){};logoUri=d.data!!.toString();saveMeta();Toast.makeText(this,"تم اختيار الشعار",Toast.LENGTH_SHORT).show();settings();return};if(r==700&&c==RESULT_OK&&d?.data!=null){restoreFromUri(d.data!!);return};if(r==703&&c==RESULT_OK&&d?.data!=null){try{contentResolver.openInputStream(d.data!!)?.use{stream->val a=JSONArray(stream.bufferedReader(Charsets.UTF_8).readText());val incoming=mutableListOf<Q>();for(i in 0 until a.length())incoming.add(qFromJson(a.getJSONObject(i)));val added=addToBankUnique(incoming);Toast.makeText(this,"تم استيراد $added سؤالًا جديدًا",Toast.LENGTH_LONG).show();bankScreen()}}catch(e:Exception){Toast.makeText(this,"ملف بنك الأسئلة غير صالح: ${e.message}",Toast.LENGTH_LONG).show()};return};if(r==705&&c==RESULT_OK&&d?.data!=null){try{contentResolver.openInputStream(d.data!!)?.use{stream->val incoming=JSONArray(stream.bufferedReader(Charsets.UTF_8).readText());val cur=try{JSONArray(pref.getString("templates","[]"))}catch(_:Exception){JSONArray()};var added=0;for(i in 0 until incoming.length()){val o=incoming.getJSONObject(i);val name=o.optString("name","قالب");var exists=false;for(j in 0 until cur.length())if(cur.getJSONObject(j).optString("name")==name)exists=true;if(!exists){cur.put(o);added++}};pref.edit().putString("templates",cur.toString()).apply();Toast.makeText(this,"تم استيراد $added قالبًا",Toast.LENGTH_LONG).show();templatesScreen()}}catch(e:Exception){Toast.makeText(this,"ملف القوالب غير صالح",Toast.LENGTH_LONG).show()};return};if(r==701&&c==RESULT_OK&&d?.data!=null){try{contentResolver.openInputStream(d.data!!)?.use{stream->val txt=stream.bufferedReader(Charsets.UTF_8).readText();restoreExamJson(JSONObject(txt));Toast.makeText(this,"تم استيراد الاختبار",Toast.LENGTH_LONG).show();home()}}catch(e:Exception){Toast.makeText(this,"ملف الاختبار غير صالح: ${e.message}",Toast.LENGTH_LONG).show()};return};if(r==500&&c==RESULT_OK&&d?.data!=null)try{contentResolver.openOutputStream(d.data!!)?.use{it.write(pending)};startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type=pendingMime;putExtra(Intent.EXTRA_STREAM,d.data!!);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"مشاركة الملف"))}catch(e:Exception){Toast.makeText(this,"تعذر حفظ الملف: ${e.message}",Toast.LENGTH_LONG).show()}}
}

}